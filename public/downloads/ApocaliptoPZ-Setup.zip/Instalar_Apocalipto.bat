@echo off
title Instalador Apocalipto PZ
cls
echo ========================================================
echo         APOCALIPTO PZ - INICIALIZADOR DE INSTALACION
echo ========================================================
echo.
echo Desbloqueando permisos de Windows (Smart App Control)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path '.\ApocaliptoPZ-Setup.exe') { Unblock-File '.\ApocaliptoPZ-Setup.exe' }" >nul 2>&1

echo Iniciando instalador oficial...
start "" ".\ApocaliptoPZ-Setup.exe"
exit
